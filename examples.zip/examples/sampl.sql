SELECT * FROM product,product_discount WHERE product.productId=product_discount.product_id;


SELECT * FROM product_discount WHERE product.productId=product_discount.product_id;


SELECT * FROM subcategory;product

DELETE * FROM product,product_discount WHERE product.productId=product_discount.product_id AND product.productId='6';

DELETE messages , usersmessages  FROM messages  INNER JOIN usersmessages  
WHERE messages.messageid= usersmessages.messageid AND messages.messageid = '1'


DELETE messages , usersmessages  FROM messages  INNER JOIN usersmessages  
WHERE messages.messageid= usersmessages.messageid AND messages.messageid = '1'

DELETE FROM product WHERE productid=6;projectpms

DELETE FROM product_discount WHERE product_id=7;

DELETE FROM product_discount WHERE product_id=4787;