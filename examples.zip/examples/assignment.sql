CREATE DATABASE Assignments;
USE Assignments;

CREATE TABLE Flights(flno INT PRIMARY KEY,ffrom VARCHAR(10) NOT NULL,fto VARCHAR(10)NOT NULL,distance INT NOT NULL,departs TIME NOT NULL,arrives TIME NOT NULL,price REAL NOT NULL);

DROP TABLE flights;
CREATE TABLE Aircraft(aid INT REFERENCES flights(flno), aname VARCHAR(10)NOT NULL, cruisingrange INT NOT NULL);

CREATE TABLE Employees(eid INT PRIMARY KEY, ename VARCHAR(10)NOT NULL, salary INT NOT NULL);


CREATE TABLE Certified(eid INT REFERENCES employees(eid), aid INT REFERENCES aircraft(aid));


INSERT INTO flights VALUES(1001,'Chennai','pune',600,'12','13',6500);
SELECT * FROM flights;

INSERT INTO flights VALUES(1001,'Chennai','pune',600,'12:00:00','1:00:00',8500),
			(1002,'Bangalore','Delhi',1200,'12:00:00','03:00:00',10500),
			(1003,'Trivandrum','pune',600,'09:00:00','12:00:00',16000),
			(1004,'Delhi','Hyderabad',1200,'1:00:00','5:00:00',22000),
			(1005,'Trivandrum','Bangalore',1100,'2:00:00','4:30:00',19000),
			(1006,'Chennai','Delhi',700,'12:00:00','2:30:00',14000);


SELECT * FROM aircraft;
INSERT INTO aircraft VALUES(1001,'AirIndia',2000),
			(1002,'Kingfisher',1500),
			(1003,'sahara',2400),
			(1004,'AirIndia',2600),
			(1005,'Spicejet',1590),
			(1006,'AirIndia',3000);
			
INSERT INTO employees VALUES(123,'kavya',40000),	
				(124,'lahari',34000),
				(125,'Alisha',26000),
				(126,'Remya',35000),
				(127,'Kuttan',50000),
				(128,'Soumya',45000);
				
INSERT INTO certified VALUES(123,1004),
				(124,1002),
				(125,1001),
				(126,1005),
				(127,1006),
				(128,1003);
			SELECT * FROM employees;
			
		SELECT aname FROM aircraft WHERE aid IN(SELECT aid FROM certified WHERE aid IN(SELECT eid FROM employees WHERE salary<8000));	
			
		SELECT * FROM certified;
		SELECT * FROM aircraft;	

SELECT (SELECT eid FROM certified GROUP BY eid HAVING COUNT(aid)>3)eid,MAX(cruisingrange) FROM aircraft a;

SELECT eid,MAX(cruisingrange) FROM (SELECT eid,cruisingrange FROM aircraft a,certified c WHERE a.aid=c.aid)table1 GROUP BY eid;




SELECT eid,MAX(cruisingrange) FROM (SELECT eid,cruisingrange FROM aircraft a,certified c WHERE a.aid=c.aid GROUP BY eid HAVING COUNT(c.aid)>3)table1 GROUP BY eid;


SELECT ename FROM employees WHERE salary<(SELECT MIN(price) FROM flights WHERE ffrom='chennai' AND fto='delhi');

SELECT aname,AVG(salary) FROM aircraft a,certified c,employees e WHERE a.aid=c.aid AND c.eid=e.eid AND cruisingrange=2000;
		
SELECT aname,AVG(salary) FROM employees,aircraft WHERE eid IN(SELECT eid FROM certified WHERE aid=(SELECT aid FROM aircraft WHERE cruisingrange=2000));	



SELECT aid FROM aircraft a,flights f WHERE a.aid=f.flno AND ffrom='chennai' AND fto='delhi';


































USE capdb;

SELECT * FROM employee;


CREATE VIEW empView AS 
SELECT empid,firstname FROM employee WHERE salary>20000;

SELECT * FROM empView;

USE teacher;

USE capdb;

SELECT COUNT(*) FROM employee;

SELECT * FROM employee;

DELETE FROM employee WHERE salary<20000;

ROLLBACK;



SELECT COUNT(*) FROM employee;

SELECT * FROM employee;
SET autocommit=FALSE;

DELETE FROM employee WHERE salary>20000;

ROLLBACK;


CALL addNumbers(@output);
SELECT @output;


CALL printnames('Sree','libin',@outvalue)








		