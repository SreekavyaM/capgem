USE assignments;
CREATE TABLE userlogin(username VARCHAR(50),passwrd VARCHAR(50));

INSERT INTO userlogin VALUES('kavya','libi123'),
			('abhishek','qwerty'),
			('lahari','nags123'),
			('divya','sandeep'),
			('kalitha','qwerty');
			
			USE projectpms;