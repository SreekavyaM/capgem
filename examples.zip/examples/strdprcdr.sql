DELIMITER $$

CREATE
    PROCEDURE `capdb`.`printnames`(IN fname VARCHAR(50),IN lname VARCHAR(50),OUT greetings VARCHAR(50))
    
   
    BEGIN
    
    DECLARE msg VARCHAR(100)
    SET msg=CONCAT('Hello ',fname,' ',lname);
    SET greetings=msg;

    END$$

DELIMITER ;